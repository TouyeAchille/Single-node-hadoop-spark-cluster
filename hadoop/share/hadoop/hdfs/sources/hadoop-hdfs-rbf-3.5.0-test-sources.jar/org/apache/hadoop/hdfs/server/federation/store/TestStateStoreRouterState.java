/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.hadoop.hdfs.server.federation.store;

import static org.apache.hadoop.hdfs.server.federation.FederationTestUtils.verifyException;
import static org.apache.hadoop.hdfs.server.federation.store.FederationStateStoreTestUtils.clearRecords;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.hadoop.hdfs.server.federation.router.FederationUtil;
import org.apache.hadoop.hdfs.server.federation.router.RBFConfigKeys;
import org.apache.hadoop.hdfs.server.federation.router.RouterServiceState;
import org.apache.hadoop.hdfs.server.federation.store.protocol.GetRouterRegistrationRequest;
import org.apache.hadoop.hdfs.server.federation.store.protocol.GetRouterRegistrationsRequest;
import org.apache.hadoop.hdfs.server.federation.store.protocol.RouterHeartbeatRequest;
import org.apache.hadoop.hdfs.server.federation.store.records.RouterState;
import org.apache.hadoop.test.GenericTestUtils;
import org.apache.hadoop.util.Time;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

/**
 * Test the basic {@link StateStoreService} {@link RouterStore} functionality.
 */
public class TestStateStoreRouterState extends TestStateStoreBase {

  private static RouterStore routerStore;

  @BeforeAll
  public static void create() {
    // Reduce expirations to 2 seconds
    getConf().setTimeDuration(
        RBFConfigKeys.FEDERATION_STORE_ROUTER_EXPIRATION_MS,
        2, TimeUnit.SECONDS);
    // Set deletion time to 2 seconds
    getConf().setTimeDuration(
        RBFConfigKeys.FEDERATION_STORE_ROUTER_EXPIRATION_DELETION_MS,
        2, TimeUnit.SECONDS);
  }

  @BeforeEach
  public void setup() throws IOException, InterruptedException {

    if (routerStore == null) {
      routerStore =
          getStateStore().getRegisteredRecordStore(RouterStore.class);
    }

    // Clear router status registrations
    assertTrue(clearRecords(getStateStore(), RouterState.class));
  }

  @Test
  public void testStateStoreDisconnected() throws Exception {

    // Close the data store driver
    getStateStore().closeDriver();
    assertEquals(false, getStateStore().isDriverReady());

    // Test all APIs that access the data store to ensure they throw the correct
    // exception.
    GetRouterRegistrationRequest getSingleRequest =
        GetRouterRegistrationRequest.newInstance();
    verifyException(routerStore, "getRouterRegistration",
        StateStoreUnavailableException.class,
        new Class[] {GetRouterRegistrationRequest.class},
        new Object[] {getSingleRequest});

    GetRouterRegistrationsRequest getRequest =
        GetRouterRegistrationsRequest.newInstance();
    routerStore.loadCache(true);
    verifyException(routerStore, "getRouterRegistrations",
        StateStoreUnavailableException.class,
        new Class[] {GetRouterRegistrationsRequest.class},
        new Object[] {getRequest});

    RouterHeartbeatRequest hbRequest = RouterHeartbeatRequest.newInstance(
        RouterState.newInstance("test", 0, RouterServiceState.UNINITIALIZED));
    verifyException(routerStore, "routerHeartbeat",
        StateStoreUnavailableException.class,
        new Class[] {RouterHeartbeatRequest.class},
        new Object[] {hbRequest});
  }

  //
  // Router
  //
  @Test
  public void testUpdateRouterStatus()
      throws IllegalStateException, IOException {

    long dateStarted = Time.now();
    String address = "testaddress";

    // Set
    RouterHeartbeatRequest request = RouterHeartbeatRequest.newInstance(
        RouterState.newInstance(
            address, dateStarted, RouterServiceState.RUNNING));
    assertTrue(routerStore.routerHeartbeat(request).getStatus());

    // Verify
    GetRouterRegistrationRequest getRequest =
        GetRouterRegistrationRequest.newInstance(address);
    RouterState record =
        routerStore.getRouterRegistration(getRequest).getRouter();
    assertNotNull(record);
    assertEquals(RouterServiceState.RUNNING, record.getStatus());
    assertEquals(address, record.getAddress());
    assertEquals(FederationUtil.getCompileInfo(), record.getCompileInfo());
    // Build version may vary a bit
    assertFalse(record.getVersion().isEmpty());
  }

  @Test
  public void testRouterStateExpiredAndDeletion()
      throws IOException, InterruptedException, TimeoutException {

    long dateStarted = Time.now();
    String address = "testaddress";

    RouterHeartbeatRequest request = RouterHeartbeatRequest.newInstance(
        RouterState.newInstance(
            address, dateStarted, RouterServiceState.RUNNING));
    // Set
    assertTrue(routerStore.routerHeartbeat(request).getStatus());

    // Verify
    GetRouterRegistrationRequest getRequest =
        GetRouterRegistrationRequest.newInstance(address);
    RouterState record =
        routerStore.getRouterRegistration(getRequest).getRouter();
    assertNotNull(record);

    // Wait past expiration (set in conf to 2 seconds)
    GenericTestUtils.waitFor(() -> {
      try {
        RouterState routerState = routerStore
            .getRouterRegistration(getRequest).getRouter();
        // Verify entry is expired
        return routerState.getStatus() == RouterServiceState.EXPIRED;
      } catch (IOException e) {
        return false;
      }
    }, 100, 3000);

    // Heartbeat again and this shouldn't be EXPIRED at this point
    assertTrue(routerStore.routerHeartbeat(request).getStatus());
    RouterState r = routerStore.getRouterRegistration(getRequest).getRouter();
    assertEquals(RouterServiceState.RUNNING, r.getStatus());

    // Wait past expiration (set in conf to 2 seconds)
    GenericTestUtils.waitFor(() -> {
      try {
        RouterState routerState = routerStore
            .getRouterRegistration(getRequest).getRouter();
        // Verify entry is expired
        return routerState.getStatus() == RouterServiceState.EXPIRED;
      } catch (IOException e) {
        return false;
      }
    }, 100, 3000);

    // Wait deletion (set in conf to 2 seconds)
    GenericTestUtils.waitFor(() -> {
      try {
        RouterState routerState = routerStore
            .getRouterRegistration(getRequest).getRouter();
        // Verify entry is deleted
        return routerState.getStatus() == null;
      } catch (IOException e) {
        return false;
      }
    }, 100, 3000);
  }

  @Test
  public void testGetAllRouterStates()
      throws StateStoreUnavailableException, IOException {

    // Set 2 entries
    RouterHeartbeatRequest heartbeatRequest1 =
        RouterHeartbeatRequest.newInstance(
            RouterState.newInstance(
                "testaddress1", Time.now(), RouterServiceState.RUNNING));
    assertTrue(routerStore.routerHeartbeat(heartbeatRequest1).getStatus());

    RouterHeartbeatRequest heartbeatRequest2 =
        RouterHeartbeatRequest.newInstance(
            RouterState.newInstance(
                "testaddress2", Time.now(), RouterServiceState.RUNNING));
    assertTrue(routerStore.routerHeartbeat(heartbeatRequest2).getStatus());

    // Verify
    routerStore.loadCache(true);
    GetRouterRegistrationsRequest request =
        GetRouterRegistrationsRequest.newInstance();
    List<RouterState> entries =
        routerStore.getRouterRegistrations(request).getRouters();
    assertEquals(2, entries.size());
    Collections.sort(entries);
    assertEquals("testaddress1", entries.get(0).getAddress());
    assertEquals("testaddress2", entries.get(1).getAddress());
    assertEquals(RouterServiceState.RUNNING, entries.get(0).getStatus());
    assertEquals(RouterServiceState.RUNNING, entries.get(1).getStatus());
  }
}
