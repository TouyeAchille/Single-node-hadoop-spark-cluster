/*
 * Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package org.apache.hadoop.fs.contract.router.web;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.contract.AbstractContractOpenTest;
import org.apache.hadoop.fs.contract.AbstractFSContract;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.IOException;

/**
 * Test open operations on a Router WebHDFS FS.
 */
public class TestRouterWebHDFSContractOpen extends AbstractContractOpenTest {

  @BeforeAll
  public static void createCluster() throws IOException {
    RouterWebHDFSContract.createCluster();
  }

  @AfterAll
  public static void teardownCluster() throws IOException {
    RouterWebHDFSContract.destroyCluster();
  }

  @Override
  protected AbstractFSContract createContract(Configuration conf) {
    return new RouterWebHDFSContract(conf);
  }

  @Override
  @Test
  public void testOpenReadDir() throws Throwable {
    // WebHDFS itself allows open read on directory, we may need to
    // fix this first before make this test work
  }

  @Override
  @Test
  public void testOpenReadDirWithChild() throws Throwable {
    // WebHDFS itself allows open read on directory, we may need to
    // fix this first before make this test work
  }
}
